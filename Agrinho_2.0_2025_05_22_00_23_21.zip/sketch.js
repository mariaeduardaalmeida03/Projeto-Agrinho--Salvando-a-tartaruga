let tartaruga;
let obstaculos = [];
let chegou = false;

function setup() {
  createCanvas(600, 400);
  tartaruga = new Tartaruga();
  textSize(18);
}

function draw() {
  // fundo: areia e mar
  background(255, 230, 180); // areia
  noStroke();
  fill(100, 200, 255); // mar
  rect(0, 0, width, 80);
  fill(0);
  text("Leve a tartaruga até o mar! 🐢", 180, 30);

  // mostrar tartaruga
  if (!chegou) {
    tartaruga.mover(mouseX, mouseY);
    tartaruga.mostrar();

    // gerar lixo
    if (frameCount % 60 === 0) {
      obstaculos.push(new Obstaculo());
    }

    // mover e mostrar obstáculos
    for (let i = obstaculos.length - 1; i >= 0; i--) {
      obstaculos[i].mover();
      obstaculos[i].mostrar();

      if (obstaculos[i].bateu(tartaruga)) {
        fill(255, 0, 0);
        text("A tartaruga foi atingida! 😢", 180, height / 2);
        noLoop();
      }
    }

    // verificar se chegou ao mar
    if (tartaruga.y < 80) {
      chegou = true;
    }
  } else {
    fill(0, 150, 0);
    text("A tartaruga chegou ao mar! 🎉", 180, height / 2);
  }
}

// Classe da tartaruga
class Tartaruga {
  constructor() {
    this.x = width / 2;
    this.y = height - 40;
    this.tam = 20;
  }

  mover(novoX, novoY) {
    // suaviza o movimento com lerp
    this.x = lerp(this.x, novoX, 0.1);
    this.y = lerp(this.y, novoY, 0.1);

    // limitar à tela
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }

  mostrar() {
    fill(34, 139, 34);
    ellipse(this.x, this.y, this.tam * 1.5, this.tam);
    ellipse(this.x - 10, this.y, 10, 10); // nadadeira esquerda
    ellipse(this.x + 10, this.y, 10, 10); // nadadeira direita
  }
}

// Classe de obstáculo (lixo)
class Obstaculo {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.vel = random(2, 4);
    this.tam = 20;
  }

  mover() {
    this.y += this.vel;
  }

  mostrar() {
    fill(120);
    rect(this.x, this.y, this.tam, this.tam);
  }

  bateu(tartaruga) {
    return (
      this.x < tartaruga.x + tartaruga.tam / 2 &&
      this.x + this.tam > tartaruga.x - tartaruga.tam / 2 &&
      this.y < tartaruga.y + tartaruga.tam / 2 &&
      this.y + this.tam > tartaruga.y - tartaruga.tam / 2
    );
  }
}
